#ifndef _TYPES_H__
#define _TYPES_H__

#ifndef NULL
#define NULL 0
#endif

#include <stdint.h>

//typedef unsigned short uint16_t;
//typedef signed short int16_t;

typedef const unsigned char * string_t;

#endif