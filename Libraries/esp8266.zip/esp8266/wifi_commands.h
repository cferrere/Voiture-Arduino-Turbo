#ifndef __WIFI_COMMANDS__
#define __WIFI_COMMANDS__

#include <Arduino.h>

#ifdef __cplusplus
extern "C"{
#endif

void register_wifi_commands();

#ifdef __cplusplus
} // extern "C"
#endif

#endif