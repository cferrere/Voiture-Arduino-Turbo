#ifndef __BASIC_COMMANDS__
#define __BASIC_COMMANDS__

#include <Arduino.h>

#ifdef __cplusplus
extern "C"{
#endif

void register_basic_commands();

#ifdef __cplusplus
} // extern "C"
#endif

#endif