
#define FIRMWARE_VERSION "0.0.1"
#define AT_VERSION "1.0.0"

#ifndef AT_COMMANDS_NUM
#define AT_COMMANDS_NUM 3
#endif
